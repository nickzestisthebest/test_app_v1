"""Builds the installable app into public/ from the Sprout app file.
Usage: python3 tools/build_pwa.py [path/to/sprout_v2.html]
Then:  node tools/gen_prompts.mjs   (lets the server recognize the app's AI prompts)"""
import hashlib, json, os, sys
from PIL import Image
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'sprout'))
import brand  # the name and look: sprout_live/brand.json
B = brand.load()
from html import escape as _he

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, '..', 'sprout', 'sprout_v2.html')
ICON = os.path.join(ROOT, B.get('iconFile') or 'tools/icon_1024.png')
PUB = os.path.join(ROOT, 'public')
os.makedirs(os.path.join(PUB, 'icons'), exist_ok=True)

s = open(SRC, encoding='utf-8').read()
assert s.count('<title>Sprout v2</title>') == 1
s = s.replace('<title>Sprout v2</title>', '<title>' + _he(B['name']) + '</title>')
HEAD = ('<meta name="theme-color" content="' + B['themeColor'] + '">'
        '<meta name="description" content="' + _he(B['name'] + ': ' + B['description'][:1].lower() + B['description'][1:]) + '">'
        '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">'
        '<meta name="apple-mobile-web-app-status-bar-style" content="default"><meta name="apple-mobile-web-app-title" content="' + _he(B['name']) + '">'
        '<meta name="format-detection" content="telephone=no">'
        '<link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">'
        '<link rel="icon" type="image/png" sizes="192x192" href="/icons/icon-192.png">'
        '<script>window.SPROUT_BUILD=\'__BUILD__\'</script>')
vp = '<meta name=viewport content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">'
assert s.count(vp) == 1
s = s.replace(vp, vp + HEAD)
# the build id lets an open copy of the app notice a newer version and reload itself
ver = hashlib.sha256(s.encode('utf-8')).hexdigest()[:10]
s = s.replace("__BUILD__", ver)
open(os.path.join(PUB, 'index.html'), 'w', encoding='utf-8').write(s)

im = Image.open(ICON).convert('RGB')
for name, size in [('apple-touch-icon.png', 180), ('icon-192.png', 192), ('icon-512.png', 512), ('maskable-512.png', 512), ('favicon-32.png', 32)]:
    im.resize((size, size), Image.LANCZOS).save(os.path.join(PUB, 'icons', name), optimize=True)

man = {
    'name': B['name'], 'short_name': B['name'][:12], 'id': '/', 'start_url': '/', 'scope': '/',
    'display': 'standalone', 'orientation': 'portrait', 'background_color': B['backgroundColor'], 'theme_color': B['themeColor'],
    'description': B['description'],
    'icons': [
        {'src': '/icons/icon-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any'},
        {'src': '/icons/icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any'},
        {'src': '/icons/maskable-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'}]}
open(os.path.join(PUB, 'manifest.webmanifest'), 'w').write(json.dumps(man, indent=2))

SW = r"""// Sprout offline support. The app opens without a connection; bank sync and AI need one.
const V = 'sprout-__VER__';
const SHELL = ['/', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png', '/icons/apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())) });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(n => n !== V).map(n => caches.delete(n)))).then(() => self.clients.claim())) });
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== self.location.origin || u.pathname.startsWith('/api/') || u.pathname === '/sw.js') return;
  if (r.mode === 'navigate' && u.pathname !== '/') return;
  if (r.mode === 'navigate') {
    // newest app when online, the saved copy when offline
    e.respondWith(Promise.race([fetch(r).then(res => { const c = res.clone(); if (res.ok) caches.open(V).then(x => x.put('/', c)); return res }),
      new Promise((_, no) => setTimeout(no, 8000))]).catch(() => caches.match('/').then(m => m || fetch(r))));
    return;
  }
  e.respondWith(caches.match(r).then(m => m || fetch(r).then(res => { if (res.ok) { const c = res.clone(); caches.open(V).then(x => x.put(r, c)) } return res })));
});
// notifications you chose in Sprout: show them, and open the right screen when tapped
self.addEventListener('push', e => {
  let d = {}; try { d = e.data ? e.data.json() : {} } catch (_) { d = { body: e.data ? e.data.text() : '' } }
  const url = /^\/(\?go=[a-z]*)?$/.test(String(d.url || '')) ? d.url : '/';
  e.waitUntil(self.registration.showNotification(String(d.title || 'Sprout').slice(0, 120), { body: String(d.body || '').slice(0, 240), tag: String(d.tag || 'sprout').slice(0, 80), icon: '/icons/icon-192.png', badge: '/icons/icon-192.png', data: { url } }));
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || '/';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(L => { for (const c of L) { if ('focus' in c) { c.navigate ? c.navigate(url).catch(() => 0) : 0; return c.focus() } } return self.clients.openWindow(url) }));
});
""".replace('__VER__', ver)
open(os.path.join(PUB, 'sw.js'), 'w').write(brand.brandify(SW, B))
open(os.path.join(PUB, 'robots.txt'), 'w').write('User-agent: *\nDisallow: /\n')
print('public/ built, version', ver, 'index', len(s), 'bytes')
